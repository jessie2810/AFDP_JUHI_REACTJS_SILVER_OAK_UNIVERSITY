import React from "react";

class MyClassComponent extends React.Component{
    render(){return<h2>Custom class</h2>
    }
}
export default MyClassComponent;