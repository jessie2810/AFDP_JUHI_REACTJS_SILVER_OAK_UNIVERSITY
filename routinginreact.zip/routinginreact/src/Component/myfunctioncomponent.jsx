function MyFunctionComponent(){
    return(
        <h2>Custom Function</h2>
    );
}
export default MyFunctionComponent;