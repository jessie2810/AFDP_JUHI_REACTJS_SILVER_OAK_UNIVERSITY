import React, { useState } from 'react';
import { FormGroup, FormControl, InputLabel, Input, Button, makeStyles, Typography } from '@material-ui/core';
import { addUser } from '../Service/api';
import { useNavigate } from 'react-router-dom';
import { validName,validEmail,validUserName, validPhone,validNumeric } from '../constants/regEx';

const initialValue = {
    name: '',
    username: '',
    email: '',
    phone: ''
}
const initialIsValidValue={
    isname: '',
    isusername: '',
    isemail: '',
    isphone: ''
}
const useStyles = makeStyles({
    container: {
        width: '50%',
        margin: '5% 0 0 25%',
        '& > *': {
            marginTop: 20
        }
    }
})

const AddUser = () => {
    const [user, setUser] = useState(initialValue);
    const { name, username, email, phone } = user;

    const [isValid, setIsValid]=useState(initialIsValidValue);
    const { isname,isusername, isemail, isphone} = isValid;

    const classes = useStyles();
    const validationMessageCSS = {color:'red',marginBottom:'20px'}
    let navigate = useNavigate();

    const onValidate = (e,regEx) => {
        const RegExObj=new RegExp(regEx);
        const isValidKey='is'+e.target.name;
        
        if(e.target.value==="" || RegExObj.test(e.target.value))
        {
            setIsValid({...isValid,[isValidKey]:''});
            setUser({...user, [e.target.name]: e.target.value});
        }
        else{
            setIsValid({...isValid,[isValidKey]:'Invalid '+e.target.name});
        }
    }

    var flag=true;
    const validateDetailsFlag = Object.values(isValid).every(value => {
        if (value!==null && value!=='') {
            flag=false;
        }
        return flag;
    });


    const onValueChange = (e) => {
        setUser({...user, [e.target.name]: e.target.value})
    }

    const addUserDetails = async() => {
       
        if(validateDetailsFlag)
        {
            await addUser(user);
            navigate('../all');
        }
        else{
            alert("Invalid input..!!");
        }
    }

    return (
        <FormGroup className={classes.container}>
            <Typography variant="h4">Add User</Typography>
            <FormControl>
                <InputLabel htmlFor="my-input">Name</InputLabel>
                <Input onChange={(e) => onValidate(e,validName)} onBlur={(e) => onValidate(e,validName)} name='name' value={name} id="my-input" />
                <div style={validationMessageCSS}>{isname}</div>
            </FormControl>
            <FormControl>
                <InputLabel htmlFor="my-input">Username</InputLabel>
                <Input onChange={(e) => onValueChange(e)} onBlur={(e) => onValidate(e,validUserName)} name='username' value={username} id="my-input" />
                <div style={validationMessageCSS}>{isusername}</div>
            </FormControl>
            <FormControl>
                <InputLabel htmlFor="my-input">Email</InputLabel>
                <Input onChange={(e) => onValueChange(e)} onBlur={(e) => onValidate(e,validEmail)} name='email' value={email} id="my-input"/>
                <div style={validationMessageCSS}>{isemail}</div>
            </FormControl>
            <FormControl>
                <InputLabel htmlFor="my-input">Phone</InputLabel>
                <Input onChange={(e) => onValidate(e,validNumeric)} onBlur={(e) => onValidate(e,validPhone)} name='phone' value={phone} id="my-input" />
                <div style={validationMessageCSS}>{isphone}</div>
            </FormControl>
            <FormControl>
                <Button variant="contained" color="primary" disabled={name.length===0 || phone.length===0 || email.length===0 || username.length===0} onClick={() => addUserDetails()}>Add User</Button>
            </FormControl>
        </FormGroup>
    )
}

export default AddUser;