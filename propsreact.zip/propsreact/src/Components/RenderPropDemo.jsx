import React from 'react'


// Parent component sending render props to the child
class ParentSampleRenderProps extends React.Component {
    render() {
      return (
        <ChildSampleRenderProps
          // Passing render props to the child component
          render={() => {
            return (
              <div>
                <h3> 
                    I am coming from parent sample render props.
                </h3>
              </div>
            )
          }}
        />
      )
    }
  }

// Child component getting render props
class ChildSampleRenderProps extends React.Component {
    render() {
      return (
        <div>
          <h2>I am Child Render Prop Component</h2>
          {this.props.render()}
        </div>
      )
    }
  }
    
  
    
  export default ParentSampleRenderProps;