import './App.css';
import Person from './Components/UpdateClassComponent'
//import UseStateFun from './Components/UseStateFun'
function App() {
  return (
  <Person/>
  //<UseStateFun/>
  );
  
}

export default App;