import './App.css';
import ValidationDemo from './Components/ValidationDemo';

function App() {
  return (
    
    <ValidationDemo/>
  );
}

export default App;
